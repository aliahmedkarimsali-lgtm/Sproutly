# Sprout Rewards (Android, Flutter)

A cute daily-rewards app: watch a short ad, collect points, grow a streak boost,
and cash out in USDT (TRC20 or BEP20).

This folder holds the app's code (`lib/` and `pubspec.yaml`). Flutter generates
the Android part for you, so setup takes a few minutes.

## 1. Run it on your phone

1. Install Flutter (https://docs.flutter.dev/get-started/install) and Android Studio.
2. Create a fresh project and bring this code in:
   ```
   flutter create --org com.yourname sprout_app
   ```
3. Copy this folder's `lib/` folder and `pubspec.yaml` into `sprout_app/`,
   replacing the ones that are there.
4. Open `sprout_app/android/app/src/main/AndroidManifest.xml` and add this line
   inside the `<application ...>` tag (this is Google's TEST AdMob app id):
   ```xml
   <meta-data
       android:name="com.google.android.gms.ads.APPLICATION_ID"
       android:value="ca-app-pub-3940256099942544~3347511713"/>
   ```
5. If the build complains about `minSdk`, set `minSdk = 23` in
   `android/app/build.gradle` (or `build.gradle.kts`).
6. Plug in your phone (USB debugging on), then:
   ```
   cd sprout_app
   flutter pub get
   flutter run
   ```

## 2. What works now

- Daily collect (once per day) after watching a rewarded ad.
- Streak boost: +10% per day, up to day 7.
- Up to 3 optional bonus ads per day.
- Wallet with USDT-only cash out, address format check, TRC20/BEP20 picker.
- All numbers to tune are in `lib/config.dart`.

## 3. What is NOT ready for real money (important)

The app runs in **demo mode**. Before you pay anyone:

1. **Backend server.** Points, streaks and payouts must live on your server.
   A balance stored on the phone can be edited by the user. Set
   `payoutBaseUrl` in `lib/config.dart` once the server exists.
2. **Server-side ad verification.** Use AdMob server-side verification (SSV) so
   only real, completed ad views create points.
3. **Fraud protection.** Limit one account per device, detect emulators and
   bots, and review payouts before sending them.
4. **Keep the 50/50 promise.** Compare what AdMob really pays per view with the
   points you give out (see the note at the top of `lib/config.dart`).
5. **USDT fees.** Network fees can eat a $1 payout. Consider a higher minimum.
6. **Real ad ids.** Replace Google's test ad ids (in `config.dart` and in the
   manifest) with your own from AdMob.
7. **Store rules and law.** Read Google Play's policies for rewards apps and
   crypto payouts, write a privacy policy, and check the rules in the
   countries where you will launch. Never call it "mining" or promise income.
