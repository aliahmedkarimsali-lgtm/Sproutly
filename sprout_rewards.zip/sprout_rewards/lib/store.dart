import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'config.dart';

class HistoryItem {
  const HistoryItem(this.label, this.points);
  final String label;
  final int points;
}

String _dayKey(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

/// Keeps the user's points, streak and wallet details on the phone.
///
/// DEMO ONLY: a balance kept on the device can be edited by the user. Before
/// paying real money, move points, streaks and payouts to a server.
class AppStore extends ChangeNotifier {
  AppStore._(this._prefs);
  final SharedPreferences _prefs;

  static Future<AppStore> load() async =>
      AppStore._(await SharedPreferences.getInstance());

  String get _today => _dayKey(DateTime.now());
  String get _yesterday =>
      _dayKey(DateTime.now().subtract(const Duration(days: 1)));

  // ---- balance ----
  int get points => _prefs.getInt('points') ?? 0;
  double get dollars => points / AppConfig.pointsPerDollar;
  double get progress =>
      (dollars / AppConfig.minWithdrawDollars).clamp(0.0, 1.0).toDouble();

  List<HistoryItem> get history {
    final raw = _prefs.getStringList('history') ?? const <String>[];
    return raw.map((e) {
      final i = e.lastIndexOf('|');
      return HistoryItem(e.substring(0, i), int.tryParse(e.substring(i + 1)) ?? 0);
    }).toList();
  }

  // ---- daily collect + streak ----
  bool get collectedToday => _prefs.getString('lastCollect') == _today;

  /// Current streak in days (0 if the streak was broken).
  int get streak {
    final last = _prefs.getString('lastCollect');
    if (last == _today || last == _yesterday) {
      return _prefs.getInt('streak') ?? 0;
    }
    return 0;
  }

  /// Boost that applies to the next (or today's) collect.
  double get boost =>
      AppConfig.multiplierForStreak(collectedToday ? streak : streak + 1);

  /// Returns the points earned (0 if already collected today).
  Future<int> collect() async {
    if (collectedToday) return 0;
    final newStreak = streak + 1;
    final earned =
        (AppConfig.basePointsPerCollect * AppConfig.multiplierForStreak(newStreak))
            .round();
    await _prefs.setInt('streak', newStreak);
    await _prefs.setString('lastCollect', _today);
    await _addPoints(earned, 'Daily sparkle');
    return earned;
  }

  // ---- bonus ads ----
  int get _bonusUsed =>
      _prefs.getString('bonusDay') == _today ? (_prefs.getInt('bonusUsed') ?? 0) : 0;

  int get bonusLeft => AppConfig.bonusAdsPerDay - _bonusUsed;

  Future<int> claimBonus() async {
    if (bonusLeft <= 0) return 0;
    final used = _bonusUsed;
    await _prefs.setString('bonusDay', _today);
    await _prefs.setInt('bonusUsed', used + 1);
    await _addPoints(AppConfig.bonusPointsPerAd, 'Bonus ad');
    return AppConfig.bonusPointsPerAd;
  }

  // ---- wallet ----
  String get network => _prefs.getString('network') ?? 'TRC20';
  String get address => _prefs.getString('address') ?? '';

  Future<void> saveWallet(String network, String address) async {
    await _prefs.setString('network', network);
    await _prefs.setString('address', address);
    notifyListeners();
  }

  Future<void> spendForPayout(double dollars) async {
    final p = (dollars * AppConfig.pointsPerDollar).round();
    await _addPoints(-p, 'Cash out');
  }

  Future<void> _addPoints(int delta, String label) async {
    await _prefs.setInt('points', points + delta);
    final list = List<String>.of(_prefs.getStringList('history') ?? const <String>[]);
    list.insert(0, '$label|$delta');
    await _prefs.setStringList('history', list.take(20).toList());
    notifyListeners();
  }
}
