import 'dart:convert';
import 'dart:io';

import 'config.dart';

/// Basic format check so users don't paste a wrong address by accident.
/// (It cannot prove the address is theirs or that it exists.)
bool isValidUsdtAddress(String network, String address) {
  if (network == 'TRC20') {
    return RegExp(r'^T[1-9A-HJ-NP-Za-km-z]{33}$').hasMatch(address);
  }
  // BEP20
  return RegExp(r'^0x[0-9a-fA-F]{40}$').hasMatch(address);
}

/// Sends a payout request to YOUR server. The server must check the user's
/// real balance, block duplicates and fraud, then send the USDT.
class PayoutApi {
  static bool get connected => AppConfig.payoutBaseUrl.isNotEmpty;

  static Future<bool> request({
    required double amount,
    required String network,
    required String address,
  }) async {
    if (!connected) return false;
    final client = HttpClient();
    try {
      final req = await client
          .postUrl(Uri.parse('${AppConfig.payoutBaseUrl}/payout-requests'));
      req.headers.contentType = ContentType.json;
      req.write(jsonEncode({
        'amount': amount,
        'currency': 'USDT',
        'network': network,
        'address': address,
      }));
      final res = await req.close();
      return res.statusCode >= 200 && res.statusCode < 300;
    } catch (_) {
      return false;
    } finally {
      client.close();
    }
  }
}
