import 'package:flutter/material.dart';

import 'config.dart';
import 'payout_api.dart';
import 'store.dart';
import 'theme.dart';
import 'widgets.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key, required this.store});
  final AppStore store;

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  late String _network = widget.store.network;
  late final TextEditingController _addr =
      TextEditingController(text: widget.store.address);
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _addr.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _addr.dispose();
    super.dispose();
  }

  void _toast(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _cashOut() async {
    final s = widget.store;
    final amount = s.dollars;
    final address = _addr.text.trim();

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Cash out?'),
        content: Text(
          'Send ${money(amount)} in USDT on $_network to:\n\n$address\n\n'
          'Payments to a wrong address or network cannot be recovered.',
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Confirm')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;

    await s.saveWallet(_network, address);
    if (!mounted) return;

    if (!PayoutApi.connected) {
      _toast('Demo mode: payouts are not connected to a server yet.');
      return;
    }

    setState(() => _busy = true);
    final sent = await PayoutApi.request(
        amount: amount, network: _network, address: address);
    if (sent) await s.spendForPayout(amount);
    if (!mounted) return;
    setState(() => _busy = false);
    _toast(sent ? 'Cash out requested!' : 'Could not send. Try again later.');
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.store,
      builder: (context, _) {
        final s = widget.store;
        final address = _addr.text.trim();
        final valid = isValidUsdtAddress(_network, address);
        final enough = s.dollars >= AppConfig.minWithdrawDollars;
        final canCash = enough && valid;
        final remaining = AppConfig.minWithdrawDollars - s.dollars;
        final minText = '\$${AppConfig.minWithdrawDollars.toStringAsFixed(2)}';

        String buttonLabel;
        if (!enough) {
          buttonLabel = 'Cash out at $minText';
        } else if (!valid) {
          buttonLabel = 'Enter your USDT address';
        } else {
          buttonLabel = 'Cash out ${money(s.dollars)}';
        }

        final recent = s.history.take(3).toList();

        return SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(22, 20, 22, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Wallet', style: display(26)),
              const SizedBox(height: 16),
              SoftCard(
                color: C.lavender,
                padding: const EdgeInsets.fromLTRB(22, 22, 22, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text('Your balance', style: body(14, color: C.muted)),
                    const SizedBox(height: 8),
                    Text(money(s.dollars), style: display(48)),
                    const SizedBox(height: 12),
                    ProgressTrack(value: s.progress, background: C.white),
                    const SizedBox(height: 12),
                    Text(
                      enough
                          ? 'You can cash out now!'
                          : '${money(remaining)} to go until you can cash out',
                      style: body(13, color: C.muted),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              SoftCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Get paid in USDT', style: display(18)),
                        const Pill(
                          text: 'USDT only',
                          icon: Icons.monetization_on_outlined,
                          bg: C.mint,
                          fg: C.mintInk,
                          compact: true,
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(child: _networkChip('TRC20')),
                        const SizedBox(width: 10),
                        Expanded(child: _networkChip('BEP20')),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text('Your USDT address', style: body(13, color: C.muted)),
                    const SizedBox(height: 6),
                    TextField(
                      controller: _addr,
                      style: body(15),
                      autocorrect: false,
                      enableSuggestions: false,
                      decoration: InputDecoration(
                        hintText: 'Paste your wallet address',
                        errorText: address.isNotEmpty && !valid
                            ? "This doesn't look like a valid $_network address"
                            : null,
                        filled: true,
                        fillColor: C.white,
                        contentPadding:
                            const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: const BorderSide(color: C.lavender, width: 2),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: const BorderSide(color: C.pink, width: 2),
                        ),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: const BorderSide(color: C.pinkDark, width: 2),
                        ),
                        focusedErrorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: const BorderSide(color: C.pinkDark, width: 2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Double-check the network. Wrong network means lost funds. '
                      'Network fees may be taken from your payout.',
                      style: body(12, color: C.muted),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              BigButton(
                label: buttonLabel,
                color: canCash ? C.pink : C.locked,
                textColor: canCash ? C.ink : C.muted,
                shadow: canCash ? C.pinkDark : null,
                loading: _busy,
                onPressed: canCash && !_busy ? _cashOut : null,
              ),
              const SizedBox(height: 16),
              Text('Recent', style: display(18)),
              const SizedBox(height: 8),
              SoftCard(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
                child: recent.isEmpty
                    ? Padding(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        child: Text('Nothing yet. Collect your first points!',
                            style: body(15, color: C.muted)),
                      )
                    : Column(
                        children: [
                          for (var i = 0; i < recent.length; i++)
                            Container(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              decoration: BoxDecoration(
                                border: i == recent.length - 1
                                    ? null
                                    : const Border(
                                        bottom: BorderSide(color: C.bg, width: 2)),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(recent[i].label, style: body(15)),
                                  Text(
                                    '${recent[i].points >= 0 ? '+' : '-'}'
                                    '${money(recent[i].points.abs() / AppConfig.pointsPerDollar)}',
                                    style: body(15,
                                        color: recent[i].points >= 0
                                            ? C.mintInk
                                            : C.pinkDark),
                                  ),
                                ],
                              ),
                            ),
                        ],
                      ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _networkChip(String name) {
    final selected = _network == name;
    return Semantics(
      button: true,
      selected: selected,
      label: name,
      child: Material(
        color: selected ? C.pink : C.track,
        shape: const StadiumBorder(),
        child: InkWell(
          customBorder: const StadiumBorder(),
          onTap: () => setState(() => _network = name),
          child: SizedBox(
            height: 44,
            child: Center(child: Text(name, style: body(15))),
          ),
        ),
      ),
    );
  }
}
