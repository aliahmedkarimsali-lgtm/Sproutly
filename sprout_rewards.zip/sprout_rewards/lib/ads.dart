import 'dart:async';

import 'package:google_mobile_ads/google_mobile_ads.dart';

import 'config.dart';

/// Thin wrapper around AdMob rewarded video ads.
class RewardedAds {
  static Future<void> init() async {
    await MobileAds.instance.initialize();
  }

  /// Loads and shows one rewarded ad.
  /// Returns true only if the user watched enough to earn the reward.
  static Future<bool> show() {
    final done = Completer<bool>();

    RewardedAd.load(
      adUnitId: AppConfig.rewardedAdUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          var earned = false;
          ad.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) {
              ad.dispose();
              if (!done.isCompleted) done.complete(earned);
            },
            onAdFailedToShowFullScreenContent: (ad, error) {
              ad.dispose();
              if (!done.isCompleted) done.complete(false);
            },
          );
          ad.show(onUserEarnedReward: (view, reward) {
            earned = true;
          });
        },
        onAdFailedToLoad: (error) {
          if (!done.isCompleted) done.complete(false);
        },
      ),
    );

    return done.future;
  }
}
