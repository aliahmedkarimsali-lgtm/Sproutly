/// All the numbers you may want to tune live here.
///
/// IMPORTANT: what you pay a user must stay at or below 50% of what the ad
/// network actually paid you for that user's ad views. Check your real
/// revenue per view in the AdMob dashboard, then adjust [basePointsPerCollect]
/// and [bonusPointsPerAd] so the payout never exceeds your share.
class AppConfig {
  static const appName = 'Sprout Rewards';

  /// 10,000 points = $1.00 (so 1 point = $0.0001).
  static const pointsPerDollar = 10000;

  /// Points for the daily collect, before the streak boost (40 points = $0.004).
  static const basePointsPerCollect = 40;

  /// Points for each optional bonus ad (30 points = $0.003).
  static const bonusPointsPerAd = 30;
  static const bonusAdsPerDay = 3;

  /// Streak boost: +10% per streak day, up to day 7.
  static const maxStreakDays = 7;

  static double multiplierForStreak(int streak) {
    final capped = streak < 1 ? 1 : (streak > maxStreakDays ? maxStreakDays : streak);
    return 1.0 + 0.1 * (capped - 1);
  }

  /// Raise this if USDT network fees (e.g. TRC20 ~ $1) eat too much of a payout.
  static const minWithdrawDollars = 1.0;

  /// Your backend URL, e.g. 'https://api.yourapp.com'. Leave empty for demo mode.
  static const payoutBaseUrl = '';

  /// Google's TEST rewarded ad unit. Replace with your real unit before release.
  static const rewardedAdUnitId = 'ca-app-pub-3940256099942544/5224354917';
}

/// Shows money with 3 decimals so tiny daily progress is visible ($0.004).
String money(double dollars) => '\$${dollars.toStringAsFixed(3)}';
