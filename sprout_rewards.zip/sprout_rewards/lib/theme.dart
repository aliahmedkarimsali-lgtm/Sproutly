import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class C {
  static const bg = Color(0xFFFFF0F5);
  static const ink = Color(0xFF4A3B52);
  static const muted = Color(0xFF6B5B73);
  static const pink = Color(0xFFFF8FB1);
  static const pinkDark = Color(0xFFE06A92);
  static const pinkSoft = Color(0xFFFFC2D6);
  static const lavender = Color(0xFFE4D9FF);
  static const mint = Color(0xFFD9F3E6);
  static const mintInk = Color(0xFF2F6B4F);
  static const butter = Color(0xFFFFE7A3);
  static const track = Color(0xFFF3E8F5);
  static const locked = Color(0xFFEADFEF);
  static const green = Color(0xFF4FBF8B);
  static const white = Color(0xFFFFFFFF);
}

TextStyle display(double size, {Color color = C.ink}) =>
    GoogleFonts.fredoka(fontSize: size, fontWeight: FontWeight.w600, color: color);

TextStyle body(double size, {Color color = C.ink}) =>
    GoogleFonts.nunito(fontSize: size, fontWeight: FontWeight.w700, color: color);

ThemeData buildTheme() {
  return ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: C.bg,
    colorScheme: ColorScheme.fromSeed(seedColor: C.pink, surface: C.bg),
    textTheme: GoogleFonts.nunitoTextTheme().apply(bodyColor: C.ink, displayColor: C.ink),
  );
}
