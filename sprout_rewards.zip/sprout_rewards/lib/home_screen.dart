import 'package:flutter/material.dart';

import 'ads.dart';
import 'config.dart';
import 'store.dart';
import 'theme.dart';
import 'widgets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.store});
  final AppStore store;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _busy = false;

  void _toast(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _collect() async {
    setState(() => _busy = true);
    final watched = await RewardedAds.show();
    if (!mounted) return;
    var earned = 0;
    if (watched) earned = await widget.store.collect();
    if (!mounted) return;
    setState(() => _busy = false);
    _toast(watched
        ? '+$earned points! See you tomorrow.'
        : 'No ad ready right now. Try again in a moment.');
  }

  Future<void> _bonus() async {
    setState(() => _busy = true);
    final watched = await RewardedAds.show();
    if (!mounted) return;
    var earned = 0;
    if (watched) earned = await widget.store.claimBonus();
    if (!mounted) return;
    setState(() => _busy = false);
    _toast(watched
        ? '+$earned bonus points!'
        : 'No ad ready right now. Try again in a moment.');
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.store,
      builder: (context, _) {
        final s = widget.store;
        final filled =
            s.streak > AppConfig.maxStreakDays ? AppConfig.maxStreakDays : s.streak;

        return SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(22, 20, 22, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Hi there', style: display(26)),
                      Text("Ready for today's sparkle?",
                          style: body(14, color: C.muted)),
                    ],
                  ),
                  Pill(
                    text: s.streak == 0 ? 'New streak' : 'Day ${s.streak}',
                    icon: Icons.star_rounded,
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Center(
                child: Container(
                  width: 176,
                  height: 176,
                  alignment: Alignment.center,
                  decoration:
                      const BoxDecoration(color: C.lavender, shape: BoxShape.circle),
                  child: const Mascot(size: 132),
                ),
              ),
              const SizedBox(height: 10),
              Text("Collect today's points",
                  textAlign: TextAlign.center, style: display(22)),
              const SizedBox(height: 16),
              s.collectedToday
                  ? const BigButton(
                      label: 'Collected! See you tomorrow',
                      icon: Icons.check_rounded,
                      color: C.mint,
                      textColor: C.mintInk,
                    )
                  : BigButton(
                      label: 'Watch ad & collect',
                      icon: Icons.play_arrow_rounded,
                      shadow: C.pinkDark,
                      loading: _busy,
                      onPressed: _busy ? null : _collect,
                    ),
              const SizedBox(height: 16),
              SoftCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.baseline,
                      textBaseline: TextBaseline.alphabetic,
                      children: [
                        Text('Your balance', style: body(14, color: C.muted)),
                        Text(money(s.dollars), style: display(28)),
                      ],
                    ),
                    const SizedBox(height: 10),
                    ProgressTrack(value: s.progress),
                    const SizedBox(height: 10),
                    Text(
                      'Cash out at \$${AppConfig.minWithdrawDollars.toStringAsFixed(2)}',
                      style: body(13, color: C.muted),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              SoftCard(
                color: C.mint,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Your boost', style: display(18)),
                        Pill(
                          text: 'x${s.boost.toStringAsFixed(1)} points',
                          bg: C.white,
                          compact: true,
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: List.generate(AppConfig.maxStreakDays, (i) {
                        return Expanded(
                          child: Container(
                            height: 12,
                            margin: EdgeInsets.only(
                                right: i == AppConfig.maxStreakDays - 1 ? 0 : 8),
                            decoration: BoxDecoration(
                              color: i < filled ? C.green : C.white,
                              borderRadius: BorderRadius.circular(999),
                            ),
                          ),
                        );
                      }),
                    ),
                    const SizedBox(height: 10),
                    Text('Come back every day to grow it',
                        style: body(13, color: C.mintInk)),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              OutlinedButton.icon(
                onPressed: (s.bonusLeft > 0 && !_busy) ? _bonus : null,
                icon: const Icon(Icons.card_giftcard_rounded),
                label: Text(
                  s.bonusLeft > 0
                      ? 'Bonus ad: +${AppConfig.bonusPointsPerAd} points (${s.bonusLeft} left today)'
                      : 'No bonus ads left today',
                  style: body(14),
                ),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                  foregroundColor: C.ink,
                  side: const BorderSide(color: C.lavender, width: 2),
                  shape: const StadiumBorder(),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
