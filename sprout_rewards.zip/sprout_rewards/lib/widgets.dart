import 'package:flutter/material.dart';

import 'theme.dart';

/// The little sprout friend, drawn in code.
class Mascot extends StatelessWidget {
  const Mascot({super.key, this.size = 132});
  final double size;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'A happy little sprout friend',
      image: true,
      child: CustomPaint(size: Size(size, size), painter: _MascotPainter()),
    );
  }
}

class _MascotPainter extends CustomPainter {
  Paint _fill(Color c) => Paint()..color = c;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.scale(size.width / 132);

    final stem = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round
      ..color = const Color(0xFF5FBF94);
    canvas.drawPath(
      Path()
        ..moveTo(66, 8)
        ..cubicTo(63, 18, 65, 25, 71, 30),
      stem,
    );

    const leaf = Color(0xFF8FDDB8);
    canvas.drawPath(
      Path()
        ..moveTo(71, 30)
        ..cubicTo(79, 18, 93, 18, 99, 22)
        ..cubicTo(97, 34, 85, 40, 71, 30)
        ..close(),
      _fill(leaf),
    );
    canvas.drawPath(
      Path()
        ..moveTo(66, 30)
        ..cubicTo(58, 20, 46, 20, 40, 24)
        ..cubicTo(42, 35, 53, 40, 66, 30)
        ..close(),
      _fill(leaf),
    );

    canvas.drawOval(
      Rect.fromCenter(center: const Offset(66, 82), width: 92, height: 84),
      _fill(C.pink),
    );

    // eyes + shine
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(48, 76), width: 11, height: 14),
      _fill(C.ink),
    );
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(84, 76), width: 11, height: 14),
      _fill(C.ink),
    );
    canvas.drawCircle(const Offset(46, 73.5), 1.8, _fill(C.white));
    canvas.drawCircle(const Offset(82, 73.5), 1.8, _fill(C.white));

    // cheeks
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(36, 92), width: 16, height: 10),
      _fill(C.pinkSoft),
    );
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(96, 92), width: 16, height: 10),
      _fill(C.pinkSoft),
    );

    // smile
    canvas.drawPath(
      Path()
        ..moveTo(58, 92)
        ..quadraticBezierTo(66, 100, 74, 92),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3.5
        ..strokeCap = StrokeCap.round
        ..color = C.ink,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Big round button with a soft "pressable" shadow.
class BigButton extends StatelessWidget {
  const BigButton({
    super.key,
    required this.label,
    this.icon,
    this.onPressed,
    this.loading = false,
    this.color = C.pink,
    this.textColor = C.ink,
    this.shadow,
  });

  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final bool loading;
  final Color color;
  final Color textColor;
  final Color? shadow;

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null && !loading;
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(999),
        boxShadow: enabled && shadow != null
            ? [BoxShadow(color: shadow!, offset: const Offset(0, 5))]
            : null,
      ),
      child: SizedBox(
        width: double.infinity,
        height: 58,
        child: FilledButton(
          onPressed: enabled ? onPressed : null,
          style: FilledButton.styleFrom(
            backgroundColor: color,
            foregroundColor: textColor,
            disabledBackgroundColor: color,
            disabledForegroundColor: textColor,
            shape: const StadiumBorder(),
          ),
          child: loading
              ? SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(strokeWidth: 3, color: textColor),
                )
              : Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (icon != null) ...[
                      Icon(icon, size: 22),
                      const SizedBox(width: 10),
                    ],
                    Flexible(
                      child: Text(label,
                          overflow: TextOverflow.ellipsis,
                          style: display(20, color: textColor)),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

class SoftCard extends StatelessWidget {
  const SoftCard({super.key, required this.child, this.color = C.white, this.padding});
  final Widget child;
  final Color color;
  final EdgeInsets? padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding ?? const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(24)),
      child: child,
    );
  }
}

class ProgressTrack extends StatelessWidget {
  const ProgressTrack({
    super.key,
    required this.value,
    this.color = C.pink,
    this.background = C.track,
  });
  final double value;
  final Color color;
  final Color background;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      value: '${(value * 100).round()} percent',
      child: ClipRRect(
        borderRadius: BorderRadius.circular(999),
        child: LinearProgressIndicator(
          value: value,
          minHeight: 14,
          backgroundColor: background,
          valueColor: AlwaysStoppedAnimation(color),
        ),
      ),
    );
  }
}

class Pill extends StatelessWidget {
  const Pill({
    super.key,
    required this.text,
    this.icon,
    this.bg = C.butter,
    this.fg = C.ink,
    this.compact = false,
  });
  final String text;
  final IconData? icon;
  final Color bg;
  final Color fg;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: compact ? 12 : 14, vertical: compact ? 4 : 8),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(999)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: compact ? 16 : 18, color: fg),
            const SizedBox(width: 6),
          ],
          Text(text, style: body(compact ? 13 : 14, color: fg)),
        ],
      ),
    );
  }
}
